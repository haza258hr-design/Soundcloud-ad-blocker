---
name: Bug report
about: Report an ad miss, incorrect mute, or playback problem
title: ""
labels: ""
assignees: ""
---

## What happened?
Describe expected and actual behavior.

## Environment
- Guard version:
- Browser and version:
- Operating system:
- Request blocking on/off:
- Mute/skip fallback on/off:
- Other blockers enabled:

## Checks
- [ ] I reloaded the extension and refreshed SoundCloud.
- [ ] I ran Test blocking rules and noted the result.
- [ ] I checked whether the popup reported an ad or lost connection.

## Reproduction and rule-test result

## Optional diagnostic report
Enable event recording before reproducing. Review any report before attaching it:
remove identifying song titles/media paths. Never attach cookies, tokens,
authorization headers, browser profiles or raw HAR files.
